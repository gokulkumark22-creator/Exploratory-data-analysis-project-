import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Upload from './pages/Upload'
import Overview from './pages/Overview'
import Statistics from './pages/Statistics'
import Visualization from './pages/Visualization'
import Correlation from './pages/Correlation'
import Insights from './pages/Insights'
import Report from './pages/Report'
import Dashboard from './pages/Dashboard'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/upload" element={<Upload />} />
        <Route path="/overview" element={<Overview />} />
        <Route path="/statistics" element={<Statistics />} />
        <Route path="/visualization" element={<Visualization />} />
        <Route path="/correlation" element={<Correlation />} />
        <Route path="/insights" element={<Insights />} />
        <Route path="/report" element={<Report />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="*" element={<Home />} />
      </Route>
    </Routes>
  )
}
