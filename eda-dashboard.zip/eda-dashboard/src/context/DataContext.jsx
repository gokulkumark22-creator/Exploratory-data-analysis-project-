import React, { createContext, useContext, useMemo, useState, useCallback } from 'react'
import { parseDatasetFile, formatFileSize } from '../utils/fileParser'
import { inferColumnType } from '../utils/statistics'
import { DEMO_DATASET_ROWS, DEMO_DATASET_META } from '../data/sampleDataset'

const DataContext = createContext(null)

function shapeRows(rows, meta) {
  const columns = Object.keys(rows[0] || {})
  const columnTypes = {}
  columns.forEach((col) => {
    columnTypes[col] = inferColumnType(rows.map((r) => r[col]))
  })
  const numericColumns = columns.filter((c) => columnTypes[c] === 'numeric')
  const categoricalColumns = columns.filter((c) => columnTypes[c] !== 'numeric')

  return {
    ...meta,
    rows,
    rowCount: rows.length,
    columns,
    columnCount: columns.length,
    columnTypes,
    numericColumns,
    categoricalColumns,
    uploadedAt: meta.uploadedAt || new Date().toISOString(),
  }
}

export function DataProvider({ children }) {
  const [dataset, setDataset] = useState(null)
  const [status, setStatus] = useState('idle') // idle | loading | ready | error
  const [error, setError] = useState(null)
  const [isDemo, setIsDemo] = useState(false)

  const loadFile = useCallback(async (file) => {
    setStatus('loading')
    setError(null)
    try {
      const parsed = await parseDatasetFile(file)
      setDataset(parsed)
      setIsDemo(false)
      setStatus('ready')
      return parsed
    } catch (err) {
      setError(err.message || 'Something went wrong while reading this file.')
      setStatus('error')
      throw err
    }
  }, [])

  const loadDemo = useCallback(() => {
    setStatus('loading')
    setError(null)
    try {
      const rows = DEMO_DATASET_ROWS
      const shaped = shapeRows(rows, {
        fileName: DEMO_DATASET_META.fileName,
        fileSize: 18841,
        fileSizeLabel: DEMO_DATASET_META.fileSizeLabel,
      })
      setDataset(shaped)
      setIsDemo(true)
      setStatus('ready')
      return shaped
    } catch (err) {
      setError('Could not load the demo dataset.')
      setStatus('error')
      throw err
    }
  }, [])

  const reset = useCallback(() => {
    setDataset(null)
    setStatus('idle')
    setError(null)
    setIsDemo(false)
  }, [])

  const value = useMemo(
    () => ({ dataset, status, error, isDemo, loadFile, loadDemo, reset, formatFileSize }),
    [dataset, status, error, isDemo, loadFile, loadDemo, reset]
  )

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}

export function useDataset() {
  const ctx = useContext(DataContext)
  if (!ctx) throw new Error('useDataset must be used within a <DataProvider>')
  return ctx
}
