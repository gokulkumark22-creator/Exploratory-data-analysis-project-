import { cleanNumeric, mean, quartiles, iqrOutliers, round, valueCounts } from './statistics'

// Buckets a numeric column into `binCount` equal-width bins for histograms.
export function histogramBins(values, binCount = 10) {
  const nums = cleanNumeric(values)
  if (!nums.length) return []
  const lo = Math.min(...nums)
  const hi = Math.max(...nums)
  if (lo === hi) {
    return [{ name: `${round(lo)}`, count: nums.length }]
  }
  const width = (hi - lo) / binCount
  const bins = Array.from({ length: binCount }, (_, i) => ({
    start: lo + i * width,
    end: lo + (i + 1) * width,
    count: 0,
  }))
  nums.forEach((v) => {
    let idx = Math.floor((v - lo) / width)
    if (idx >= binCount) idx = binCount - 1
    if (idx < 0) idx = 0
    bins[idx].count += 1
  })
  return bins.map((b) => ({
    name: `${round(b.start, 1)}–${round(b.end, 1)}`,
    count: b.count,
  }))
}

// Aggregates a numeric column by a categorical column (mean by default).
export function groupByAggregate(rows, categoryCol, numericCol, agg = 'mean', limit = 12) {
  const groups = new Map()
  rows.forEach((row) => {
    const key = row[categoryCol] === '' || row[categoryCol] == null ? 'Unknown' : String(row[categoryCol])
    if (!groups.has(key)) groups.set(key, [])
    const val = Number(row[numericCol])
    if (!Number.isNaN(val)) groups.get(key).push(val)
  })
  const result = Array.from(groups.entries()).map(([name, values]) => ({
    name,
    value: agg === 'sum' ? round(values.reduce((a, b) => a + b, 0)) : round(mean(values)),
    count: values.length,
  }))
  result.sort((a, b) => b.value - a.value)
  return result.slice(0, limit)
}

// Builds box-plot statistics, optionally grouped by a categorical column.
export function boxPlotStats(rows, numericCol, groupCol = null, limit = 8) {
  if (!groupCol) {
    const values = rows.map((r) => r[numericCol])
    const { q1, q2, q3 } = quartiles(values)
    const nums = cleanNumeric(values)
    const { outliers, lower, upper } = iqrOutliers(values)
    return [
      {
        name: numericCol,
        min: round(Math.max(Math.min(...nums), lower ?? Math.min(...nums))),
        q1: round(q1),
        median: round(q2),
        q3: round(q3),
        max: round(Math.min(Math.max(...nums), upper ?? Math.max(...nums))),
        outliers: outliers.slice(0, 20).map((v) => round(v)),
      },
    ]
  }
  const groups = new Map()
  rows.forEach((row) => {
    const key = row[groupCol] === '' || row[groupCol] == null ? 'Unknown' : String(row[groupCol])
    if (!groups.has(key)) groups.set(key, [])
    groups.get(key).push(row[numericCol])
  })
  const entries = Array.from(groups.entries()).slice(0, limit)
  return entries.map(([name, values]) => {
    const { q1, q2, q3 } = quartiles(values)
    const nums = cleanNumeric(values)
    const { outliers, lower, upper } = iqrOutliers(values)
    return {
      name,
      min: round(Math.max(Math.min(...nums), lower ?? Math.min(...nums))),
      q1: round(q1),
      median: round(q2),
      q3: round(q3),
      max: round(Math.min(Math.max(...nums), upper ?? Math.max(...nums))),
      outliers: outliers.slice(0, 10).map((v) => round(v)),
    }
  })
}

// Cross-tabulates two categorical (or category-like) columns into a matrix
// of counts, used by the heatmap chart type in the Visualization page.
export function crosstab(rows, colA, colB, limitA = 8, limitB = 8) {
  const topA = valueCounts(rows.map((r) => r[colA]), limitA).map((v) => v.name)
  const topB = valueCounts(rows.map((r) => r[colB]), limitB).map((v) => v.name)

  const grid = topA.map((a) =>
    topB.map((b) => rows.filter((r) => String(r[colA]) === a && String(r[colB]) === b).length)
  )
  const max = Math.max(1, ...grid.flat())
  return { rowsLabels: topA, colsLabels: topB, grid, max }
}

export function pieData(rows, categoryCol, limit = 6) {
  const counts = valueCounts(rows.map((r) => r[categoryCol]), 999)
  if (counts.length <= limit) return counts
  const top = counts.slice(0, limit - 1)
  const rest = counts.slice(limit - 1).reduce((a, c) => a + c.value, 0)
  return [...top, { name: 'Other', value: rest }]
}
