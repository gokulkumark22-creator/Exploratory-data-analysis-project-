import Papa from 'papaparse'
import * as XLSX from 'xlsx'
import { inferColumnType } from './statistics'

const MAX_FILE_SIZE_MB = 25

export function formatFileSize(bytes) {
  if (bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return `${(bytes / 1024 ** i).toFixed(i === 0 ? 0 : 2)} ${units[i]}`
}

function buildDatasetShape(rows, fileMeta) {
  if (!rows.length) {
    throw new Error('The file is empty. Upload a dataset with at least one row of data.')
  }
  const columns = Object.keys(rows[0])
  if (!columns.length) {
    throw new Error('No columns were detected in this file.')
  }

  const columnTypes = {}
  columns.forEach((col) => {
    const values = rows.map((r) => r[col])
    columnTypes[col] = inferColumnType(values)
  })

  const numericColumns = columns.filter((c) => columnTypes[c] === 'numeric')
  const categoricalColumns = columns.filter((c) => columnTypes[c] !== 'numeric')

  return {
    fileName: fileMeta.name,
    fileSize: fileMeta.size,
    fileSizeLabel: formatFileSize(fileMeta.size),
    uploadedAt: new Date().toISOString(),
    rows,
    rowCount: rows.length,
    columns,
    columnCount: columns.length,
    columnTypes,
    numericColumns,
    categoricalColumns,
  }
}

function parseCsv(file) {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: 'greedy',
      complete: (results) => {
        if (results.errors && results.errors.length) {
          const fatal = results.errors.find((e) => e.type !== 'FieldMismatch')
          if (fatal && !results.data.length) {
            reject(new Error(`Could not parse CSV: ${fatal.message}`))
            return
          }
        }
        try {
          resolve(buildDatasetShape(results.data, file))
        } catch (err) {
          reject(err)
        }
      },
      error: (err) => reject(new Error(`Could not read CSV file: ${err.message}`)),
    })
  })
}

function parseExcel(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result)
        const workbook = XLSX.read(data, { type: 'array' })
        const firstSheetName = workbook.SheetNames[0]
        const sheet = workbook.Sheets[firstSheetName]
        const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' })
        resolve(buildDatasetShape(rows, file))
      } catch (err) {
        reject(new Error(`Could not parse Excel file: ${err.message}`))
      }
    }
    reader.onerror = () => reject(new Error('Could not read the Excel file.'))
    reader.readAsArrayBuffer(file)
  })
}

export async function parseDatasetFile(file) {
  if (!file) throw new Error('No file was selected.')

  const sizeMb = file.size / (1024 * 1024)
  if (sizeMb > MAX_FILE_SIZE_MB) {
    throw new Error(`This file is ${sizeMb.toFixed(1)} MB. Please upload a file under ${MAX_FILE_SIZE_MB} MB.`)
  }

  const name = file.name.toLowerCase()
  if (name.endsWith('.csv')) {
    return parseCsv(file)
  }
  if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
    return parseExcel(file)
  }
  throw new Error('Unsupported file type. Please upload a .csv, .xlsx, or .xls file.')
}
