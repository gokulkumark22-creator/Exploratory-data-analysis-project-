// Core descriptive-statistics helpers used across the dashboard.
// All functions are defensive: they ignore null/undefined/NaN entries
// so a column with a few missing values doesn't break the calculation.

export function cleanNumeric(values) {
  return values
    .map((v) => (typeof v === 'string' ? v.trim() : v))
    .filter((v) => v !== null && v !== undefined && v !== '')
    .map(Number)
    .filter((v) => !Number.isNaN(v))
}

export function mean(values) {
  const nums = cleanNumeric(values)
  if (!nums.length) return null
  return nums.reduce((a, b) => a + b, 0) / nums.length
}

export function median(values) {
  const nums = cleanNumeric(values).sort((a, b) => a - b)
  if (!nums.length) return null
  const mid = Math.floor(nums.length / 2)
  return nums.length % 2 !== 0 ? nums[mid] : (nums[mid - 1] + nums[mid]) / 2
}

export function mode(values) {
  const cleaned = values.filter((v) => v !== null && v !== undefined && v !== '')
  if (!cleaned.length) return null
  const counts = new Map()
  cleaned.forEach((v) => counts.set(v, (counts.get(v) || 0) + 1))
  let best = null
  let bestCount = 0
  counts.forEach((count, val) => {
    if (count > bestCount) {
      bestCount = count
      best = val
    }
  })
  return best
}

export function variance(values) {
  const nums = cleanNumeric(values)
  if (nums.length < 2) return null
  const m = mean(nums)
  const sumSq = nums.reduce((acc, v) => acc + (v - m) ** 2, 0)
  return sumSq / (nums.length - 1)
}

export function stdDev(values) {
  const v = variance(values)
  return v === null ? null : Math.sqrt(v)
}

export function min(values) {
  const nums = cleanNumeric(values)
  return nums.length ? Math.min(...nums) : null
}

export function max(values) {
  const nums = cleanNumeric(values)
  return nums.length ? Math.max(...nums) : null
}

export function quantile(values, q) {
  const nums = cleanNumeric(values).sort((a, b) => a - b)
  if (!nums.length) return null
  const pos = (nums.length - 1) * q
  const base = Math.floor(pos)
  const rest = pos - base
  if (nums[base + 1] !== undefined) {
    return nums[base] + rest * (nums[base + 1] - nums[base])
  }
  return nums[base]
}

export function quartiles(values) {
  return {
    q1: quantile(values, 0.25),
    q2: quantile(values, 0.5),
    q3: quantile(values, 0.75),
  }
}

export function iqrOutliers(values) {
  const nums = cleanNumeric(values)
  const { q1, q3 } = quartiles(nums)
  if (q1 === null || q3 === null) return { outliers: [], lower: null, upper: null }
  const iqr = q3 - q1
  const lower = q1 - 1.5 * iqr
  const upper = q3 + 1.5 * iqr
  const outliers = nums.filter((v) => v < lower || v > upper)
  return { outliers, lower, upper }
}

export function round(n, digits = 2) {
  if (n === null || n === undefined || Number.isNaN(n)) return null
  const factor = 10 ** digits
  return Math.round(n * factor) / factor
}

// Infers whether a column is numeric or categorical by sampling its values.
export function inferColumnType(values) {
  const sample = values.filter((v) => v !== null && v !== undefined && v !== '').slice(0, 200)
  if (!sample.length) return 'unknown'
  const numericCount = sample.filter((v) => !Number.isNaN(Number(v)) && v !== '').length
  return numericCount / sample.length >= 0.8 ? 'numeric' : 'categorical'
}

export function uniqueCount(values) {
  return new Set(values.filter((v) => v !== null && v !== undefined && v !== '')).size
}

export function missingCount(values) {
  return values.filter((v) => v === null || v === undefined || v === '').length
}

export function valueCounts(values, topN = 8) {
  const cleaned = values.filter((v) => v !== null && v !== undefined && v !== '')
  const counts = new Map()
  cleaned.forEach((v) => counts.set(v, (counts.get(v) || 0) + 1))
  const sorted = Array.from(counts.entries()).sort((a, b) => b[1] - a[1])
  return sorted.slice(0, topN).map(([name, value]) => ({ name: String(name), value }))
}

// Builds a full per-column summary used by Overview + Statistics pages.
export function summarizeColumn(name, values, type) {
  const total = values.length
  const missing = missingCount(values)
  const unique = uniqueCount(values)
  if (type === 'numeric') {
    const { q1, q2, q3 } = quartiles(values)
    return {
      name,
      type,
      total,
      missing,
      missingPct: total ? round((missing / total) * 100, 1) : 0,
      unique,
      mean: round(mean(values)),
      median: round(median(values)),
      mode: mode(values),
      std: round(stdDev(values)),
      variance: round(variance(values)),
      min: round(min(values)),
      max: round(max(values)),
      q1: round(q1),
      q2: round(q2),
      q3: round(q3),
    }
  }
  return {
    name,
    type,
    total,
    missing,
    missingPct: total ? round((missing / total) * 100, 1) : 0,
    unique,
    mode: mode(values),
    topValues: valueCounts(values, 5),
  }
}

export function countDuplicateRows(rows) {
  const seen = new Set()
  let duplicates = 0
  rows.forEach((row) => {
    const key = JSON.stringify(row)
    if (seen.has(key)) duplicates += 1
    else seen.add(key)
  })
  return duplicates
}

// A 0-100 "data quality" score combining completeness and duplication.
export function dataQualityScore({ rows, columns, missingTotal, duplicateRows }) {
  const totalCells = rows.length * columns.length || 1
  const completeness = 1 - missingTotal / totalCells
  const duplicateRate = rows.length ? duplicateRows / rows.length : 0
  const score = (completeness * 0.75 + (1 - duplicateRate) * 0.25) * 100
  return Math.max(0, Math.min(100, Math.round(score)))
}
