import { cleanNumeric, mean, round } from './statistics'

// Pearson correlation coefficient between two equal-length numeric arrays.
// Rows where either value is missing are dropped pairwise.
export function pearsonCorrelation(xRaw, yRaw) {
  const pairs = []
  for (let i = 0; i < xRaw.length; i += 1) {
    const x = xRaw[i]
    const y = yRaw[i]
    if (x === null || x === undefined || x === '') continue
    if (y === null || y === undefined || y === '') continue
    const xn = Number(x)
    const yn = Number(y)
    if (Number.isNaN(xn) || Number.isNaN(yn)) continue
    pairs.push([xn, yn])
  }
  if (pairs.length < 2) return null

  const xs = pairs.map((p) => p[0])
  const ys = pairs.map((p) => p[1])
  const mx = mean(xs)
  const my = mean(ys)

  let num = 0
  let denomX = 0
  let denomY = 0
  for (let i = 0; i < pairs.length; i += 1) {
    const dx = xs[i] - mx
    const dy = ys[i] - my
    num += dx * dy
    denomX += dx * dx
    denomY += dy * dy
  }
  const denom = Math.sqrt(denomX * denomY)
  if (denom === 0) return 0
  return num / denom
}

// Builds a full correlation matrix for the given numeric columns.
// columns: string[]; data: array of row objects
export function buildCorrelationMatrix(data, columns) {
  const matrix = columns.map((rowCol) =>
    columns.map((colCol) => {
      if (rowCol === colCol) return 1
      const x = data.map((r) => r[rowCol])
      const y = data.map((r) => r[colCol])
      const corr = pearsonCorrelation(x, y)
      return corr === null ? null : round(corr, 3)
    })
  )
  return matrix
}

// Extracts the strongest positive / negative pairs (excluding the diagonal
// and de-duplicating symmetric pairs) for the "strong relationships" list.
export function topCorrelationPairs(matrix, columns, limit = 5) {
  const pairs = []
  for (let i = 0; i < columns.length; i += 1) {
    for (let j = i + 1; j < columns.length; j += 1) {
      const value = matrix[i][j]
      if (value === null) continue
      pairs.push({ a: columns[i], b: columns[j], value })
    }
  }
  const positive = pairs
    .filter((p) => p.value > 0)
    .sort((a, b) => b.value - a.value)
    .slice(0, limit)
  const negative = pairs
    .filter((p) => p.value < 0)
    .sort((a, b) => a.value - b.value)
    .slice(0, limit)
  return { positive, negative, all: pairs }
}

export function correlationStrengthLabel(value) {
  const abs = Math.abs(value)
  if (abs >= 0.7) return 'Strong'
  if (abs >= 0.4) return 'Moderate'
  if (abs >= 0.2) return 'Weak'
  return 'Very weak'
}
