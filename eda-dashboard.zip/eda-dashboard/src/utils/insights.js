import { summarizeColumn, iqrOutliers, countDuplicateRows, round } from './statistics'
import { buildCorrelationMatrix, topCorrelationPairs, correlationStrengthLabel } from './correlation'

// Generates a list of structured insight objects: { type, icon, title, text }
// "type" drives the icon + accent color chosen in <InsightCard />.
export function generateInsights(dataset) {
  if (!dataset) return []
  const { rows, columns, numericColumns, categoricalColumns } = dataset
  const insights = []

  // --- Missing values -------------------------------------------------
  const missingByColumn = columns
    .map((col) => summarizeColumn(col, rows.map((r) => r[col]), dataset.columnTypes[col]))
    .filter((s) => s.missing > 0)
    .sort((a, b) => b.missing - a.missing)

  if (missingByColumn.length) {
    const worst = missingByColumn[0]
    insights.push({
      type: 'missing',
      title: 'Missing data detected',
      text: `"${worst.name}" has the most missing values — ${worst.missing} entries (${worst.missingPct}%) are empty. ${missingByColumn.length - 1 > 0 ? `${missingByColumn.length - 1} other column(s) also have gaps.` : ''}`,
    })
  } else {
    insights.push({
      type: 'quality',
      title: 'No missing values',
      text: 'Every column is fully populated — this dataset has no missing entries, which makes it ready for direct analysis.',
    })
  }

  // --- Duplicates -------------------------------------------------------
  const dupCount = countDuplicateRows(rows)
  if (dupCount > 0) {
    insights.push({
      type: 'duplicate',
      title: 'Duplicate records found',
      text: `${dupCount} row(s) appear to be exact duplicates of another row (${round((dupCount / rows.length) * 100, 1)}% of the dataset). Consider removing them before modeling.`,
    })
  }

  // --- Numeric extremes & outliers --------------------------------------
  numericColumns.slice(0, 6).forEach((col) => {
    const values = rows.map((r) => r[col])
    const summary = summarizeColumn(col, values, 'numeric')
    if (summary.max === null) return
    insights.push({
      type: 'range',
      title: `Range of "${col}"`,
      text: `Values span from ${summary.min} to ${summary.max}, with a mean of ${summary.mean} and a median of ${summary.median}.`,
    })

    const { outliers } = iqrOutliers(values)
    if (outliers.length > 0) {
      insights.push({
        type: 'outlier',
        title: `Outliers in "${col}"`,
        text: `${outliers.length} value(s) fall outside the typical range (beyond 1.5× the interquartile range) — worth a closer look before drawing conclusions.`,
      })
    }
  })

  // --- Correlations -------------------------------------------------------
  if (numericColumns.length >= 2) {
    const matrix = buildCorrelationMatrix(rows, numericColumns)
    const { positive, negative } = topCorrelationPairs(matrix, numericColumns, 3)
    if (positive.length) {
      const top = positive[0]
      insights.push({
        type: 'correlation-positive',
        title: 'Strongest positive relationship',
        text: `"${top.a}" and "${top.b}" move together (r = ${top.value}) — a ${correlationStrengthLabel(top.value).toLowerCase()} positive relationship. Remember, correlation does not imply causation.`,
      })
    }
    if (negative.length) {
      const top = negative[0]
      insights.push({
        type: 'correlation-negative',
        title: 'Strongest negative relationship',
        text: `"${top.a}" and "${top.b}" tend to move in opposite directions (r = ${top.value}) — a ${correlationStrengthLabel(top.value).toLowerCase()} negative relationship.`,
      })
    }
  }

  // --- Dominant categories -------------------------------------------------
  categoricalColumns.slice(0, 4).forEach((col) => {
    const values = rows.map((r) => r[col])
    const summary = summarizeColumn(col, values, 'categorical')
    if (summary.topValues && summary.topValues.length) {
      const top = summary.topValues[0]
      const pct = round((top.value / rows.length) * 100, 1)
      if (pct >= 30) {
        insights.push({
          type: 'category',
          title: `Dominant category in "${col}"`,
          text: `"${top.name}" accounts for ${pct}% of all records — the most common value in this column by a clear margin.`,
        })
      }
    }
  })

  // --- Influencing factors (numeric columns most correlated w/ others) ----
  if (numericColumns.length >= 3) {
    const matrix = buildCorrelationMatrix(rows, numericColumns)
    const avgAbsCorr = numericColumns.map((col, i) => {
      const others = matrix[i].filter((_, j) => j !== i && matrix[i][j] !== null)
      const avg = others.length ? others.reduce((a, b) => a + Math.abs(b), 0) / others.length : 0
      return { col, avg }
    })
    avgAbsCorr.sort((a, b) => b.avg - a.avg)
    if (avgAbsCorr[0] && avgAbsCorr[0].avg > 0.3) {
      insights.push({
        type: 'influence',
        title: 'Key influencing factor',
        text: `"${avgAbsCorr[0].col}" shows the strongest overall relationship with the other numeric features (avg |r| = ${round(avgAbsCorr[0].avg, 2)}), making it a strong candidate driver in this dataset.`,
      })
    }
  }

  return insights
}
