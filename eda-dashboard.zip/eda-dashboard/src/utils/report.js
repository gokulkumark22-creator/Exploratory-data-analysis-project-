import { summarizeColumn, countDuplicateRows, dataQualityScore } from './statistics'
import { buildCorrelationMatrix, topCorrelationPairs } from './correlation'
import { generateInsights } from './insights'

function buildReportModel(dataset) {
  const { rows, columns, numericColumns, categoricalColumns, fileName } = dataset
  const summaries = columns.map((col) => summarizeColumn(col, rows.map((r) => r[col]), dataset.columnTypes[col]))
  const missingTotal = summaries.reduce((a, s) => a + s.missing, 0)
  const duplicateRows = countDuplicateRows(rows)
  const quality = dataQualityScore({ rows, columns, missingTotal, duplicateRows })
  const insights = generateInsights(dataset)

  let correlation = null
  if (numericColumns.length >= 2) {
    const matrix = buildCorrelationMatrix(rows, numericColumns)
    const { positive, negative } = topCorrelationPairs(matrix, numericColumns, 5)
    correlation = { positive, negative }
  }

  return {
    fileName,
    generatedAt: new Date().toLocaleString(),
    rowCount: rows.length,
    columnCount: columns.length,
    numericColumns,
    categoricalColumns,
    missingTotal,
    duplicateRows,
    quality,
    summaries,
    insights,
    correlation,
  }
}

export function buildMarkdownReport(dataset) {
  const m = buildReportModel(dataset)
  const lines = []
  lines.push(`# Exploratory Data Analysis Report`)
  lines.push(``)
  lines.push(`**Dataset:** ${m.fileName}`)
  lines.push(`**Generated:** ${m.generatedAt}`)
  lines.push(``)
  lines.push(`## 1. Dataset Overview`)
  lines.push(`- Records: ${m.rowCount}`)
  lines.push(`- Features: ${m.columnCount}`)
  lines.push(`- Numeric columns: ${m.numericColumns.length} (${m.numericColumns.join(', ') || '—'})`)
  lines.push(`- Categorical columns: ${m.categoricalColumns.length} (${m.categoricalColumns.join(', ') || '—'})`)
  lines.push(``)
  lines.push(`## 2. Data Quality Analysis`)
  lines.push(`- Data quality score: ${m.quality} / 100`)
  lines.push(`- Total missing cells: ${m.missingTotal}`)
  lines.push(`- Duplicate rows: ${m.duplicateRows}`)
  lines.push(``)
  lines.push(`## 3. Statistical Summary`)
  lines.push(`| Column | Type | Missing | Unique | Mean | Median | Std Dev | Min | Max |`)
  lines.push(`|---|---|---|---|---|---|---|---|---|`)
  m.summaries.forEach((s) => {
    lines.push(
      `| ${s.name} | ${s.type} | ${s.missing} | ${s.unique} | ${s.mean ?? '—'} | ${s.median ?? '—'} | ${s.std ?? '—'} | ${s.min ?? '—'} | ${s.max ?? '—'} |`
    )
  })
  lines.push(``)
  lines.push(`## 4. Visualizations`)
  lines.push(`Interactive charts (bar, line, histogram, box plot, pie, scatter, heatmap) are available in the live dashboard's Visualization tab and are not embedded in this text export.`)
  lines.push(``)
  lines.push(`## 5. Correlation Findings`)
  if (m.correlation) {
    lines.push(`**Strongest positive relationships:**`)
    m.correlation.positive.forEach((p) => lines.push(`- ${p.a} ↔ ${p.b}: r = ${p.value}`))
    lines.push(``)
    lines.push(`**Strongest negative relationships:**`)
    m.correlation.negative.forEach((p) => lines.push(`- ${p.a} ↔ ${p.b}: r = ${p.value}`))
    lines.push(``)
    lines.push(`_Note: correlation does not necessarily imply causation._`)
  } else {
    lines.push(`Not enough numeric columns to compute correlations.`)
  }
  lines.push(``)
  lines.push(`## 6. Key Insights`)
  m.insights.forEach((i) => lines.push(`- **${i.title}:** ${i.text}`))
  lines.push(``)
  lines.push(`## 7. Final Conclusion`)
  lines.push(
    `This dataset contains ${m.rowCount} records across ${m.columnCount} features, with an overall data quality score of ${m.quality}/100. ${
      m.missingTotal > 0 || m.duplicateRows > 0
        ? 'Some missing values and/or duplicate rows were identified and should be addressed before further modeling.'
        : 'No major data quality issues were found.'
    } ${
      m.correlation && m.correlation.positive.length
        ? `The strongest relationship observed was between "${m.correlation.positive[0].a}" and "${m.correlation.positive[0].b}".`
        : ''
    }`
  )
  lines.push(``)
  lines.push(`---`)
  lines.push(`_Generated automatically by EDA Studio._`)
  return lines.join('\n')
}

export function downloadReport(dataset) {
  const markdown = buildMarkdownReport(dataset)
  const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  const safeName = (dataset.fileName || 'dataset').replace(/\.[^/.]+$/, '')
  a.href = url
  a.download = `EDA-Report-${safeName}.md`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

export { buildReportModel }
