import React, { useMemo } from 'react'
import { FileText, Download, ClipboardCheck, BarChart3, Network, Lightbulb, FlaskConical, ShieldCheck } from 'lucide-react'
import { useDataset } from '../context/DataContext'
import EmptyState from '../components/EmptyState'
import SectionHeader from '../components/SectionHeader'
import QualityGauge from '../components/QualityGauge'
import { buildReportModel, downloadReport } from '../utils/report'

const SECTIONS = [
  { icon: ClipboardCheck, title: 'Dataset Overview', text: 'Row/column counts, column types, and file metadata.' },
  { icon: ShieldCheck, title: 'Data Quality Analysis', text: 'Missing values, duplicate rows and an overall quality score.' },
  { icon: FlaskConical, title: 'Statistical Summary', text: 'Mean, median, mode, standard deviation and quartiles per column.' },
  { icon: BarChart3, title: 'Visualizations', text: 'Reference to the interactive charts available in the dashboard.' },
  { icon: Network, title: 'Correlation Findings', text: 'Strongest positive and negative relationships between features.' },
  { icon: Lightbulb, title: 'Key Insights', text: 'Automatically generated, plain-language observations.' },
]

export default function Report() {
  const { dataset } = useDataset()
  const model = useMemo(() => (dataset ? buildReportModel(dataset) : null), [dataset])

  if (!dataset || !model) {
    return <EmptyState message="Upload a dataset to generate a complete, structured EDA report you can download." />
  }

  return (
    <div className="space-y-6">
      <div className="card p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div>
          <SectionHeader
            icon={FileText}
            title="EDA report is ready"
            description={`Generated from "${model.fileName}" on ${model.generatedAt}.`}
          />
          <p className="text-sm text-ink-500 max-w-xl -mt-3">
            The report bundles the dataset overview, data quality analysis, full statistical summary, correlation findings,
            key insights, and a final written conclusion into a single downloadable Markdown file.
          </p>
        </div>
        <button
          onClick={() => downloadReport(dataset)}
          className="inline-flex items-center gap-2 bg-brand-gradient text-white font-semibold text-sm px-5 py-3 rounded-xl shadow-pop hover:opacity-90 transition-opacity shrink-0"
        >
          <Download size={16} /> Download Report
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="card p-6 flex items-center justify-center">
          <QualityGauge score={model.quality} />
        </div>
        <div className="card p-6 lg:col-span-2">
          <SectionHeader icon={ClipboardCheck} title="Report contents" description="Every section included in the download." />
          <div className="grid sm:grid-cols-2 gap-3">
            {SECTIONS.map((s) => (
              <div key={s.title} className="flex items-start gap-3 rounded-xl bg-surface-soft px-3.5 py-3">
                <s.icon size={16} className="text-brand-purple mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-ink-900">{s.title}</p>
                  <p className="text-xs text-ink-300 mt-0.5 leading-relaxed">{s.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card p-6 sm:p-8">
        <SectionHeader icon={Lightbulb} title="Final conclusion (preview)" />
        <p className="text-sm text-ink-700 leading-relaxed bg-surface-soft rounded-xl p-5">
          This dataset contains <span className="font-semibold">{model.rowCount}</span> records across{' '}
          <span className="font-semibold">{model.columnCount}</span> features, with an overall data quality score of{' '}
          <span className="font-semibold">{model.quality}/100</span>.{' '}
          {model.missingTotal > 0 || model.duplicateRows > 0
            ? 'Some missing values and/or duplicate rows were identified and should be addressed before further modeling.'
            : 'No major data quality issues were found.'}{' '}
          {model.correlation && model.correlation.positive.length
            ? `The strongest relationship observed was between "${model.correlation.positive[0].a}" and "${model.correlation.positive[0].b}".`
            : ''}
        </p>
      </div>
    </div>
  )
}
