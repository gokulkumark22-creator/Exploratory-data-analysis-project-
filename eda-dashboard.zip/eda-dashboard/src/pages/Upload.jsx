import React from 'react'
import { useNavigate } from 'react-router-dom'
import { FileText, Rows3, Columns3, HardDrive, ArrowRight, Hash, Type } from 'lucide-react'
import FileUpload from '../components/FileUpload'
import DataTable from '../components/DataTable'
import StatCard from '../components/StatCard'
import SectionHeader from '../components/SectionHeader'
import { useDataset } from '../context/DataContext'

export default function Upload() {
  const { dataset } = useDataset()
  const navigate = useNavigate()

  return (
    <div className="space-y-6">
      <div className="card p-6 sm:p-8">
        <SectionHeader
          icon={FileText}
          title="Upload your dataset"
          description="CSV and Excel (.xlsx / .xls) files are supported. Parsing happens entirely in your browser."
        />
        <FileUpload />
      </div>

      {dataset && (
        <>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={FileText} label="Dataset" value={dataset.fileName} accent="blue" />
            <StatCard icon={Rows3} label="Rows" value={dataset.rowCount.toLocaleString()} accent="purple" />
            <StatCard icon={Columns3} label="Columns" value={dataset.columnCount} accent="good" />
            <StatCard icon={HardDrive} label="File Size" value={dataset.fileSizeLabel} accent="warn" />
          </div>

          <div className="card p-6 sm:p-8">
            <SectionHeader
              icon={Type}
              title="Detected column types"
              description="Automatically inferred from a sample of each column's values."
            />
            <div className="flex flex-wrap gap-2">
              {dataset.columns.map((col) => (
                <span
                  key={col}
                  className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full border ${
                    dataset.columnTypes[col] === 'numeric'
                      ? 'bg-blue-50 border-blue-100 text-brand-blue'
                      : 'bg-violet-50 border-violet-100 text-brand-purple'
                  }`}
                >
                  {dataset.columnTypes[col] === 'numeric' ? <Hash size={11} /> : <Type size={11} />}
                  {col}
                </span>
              ))}
            </div>
            <p className="text-xs text-ink-300 mt-4">
              {dataset.numericColumns.length} numerical column(s) · {dataset.categoricalColumns.length} categorical column(s)
            </p>
          </div>

          <div className="card p-6 sm:p-8">
            <SectionHeader icon={Rows3} title="Dataset preview" description="First rows of your uploaded data." />
            <DataTable columns={dataset.columns} rows={dataset.rows} badges={dataset.columnTypes} pageSize={8} />
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => navigate('/overview')}
              className="inline-flex items-center gap-2 bg-brand-gradient text-white font-semibold text-sm px-5 py-3 rounded-xl shadow-pop hover:opacity-90 transition-opacity"
            >
              Continue to Data Overview <ArrowRight size={16} />
            </button>
          </div>
        </>
      )}
    </div>
  )
}
