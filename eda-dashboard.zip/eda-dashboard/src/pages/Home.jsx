import React from 'react'
import { useNavigate } from 'react-router-dom'
import { UploadCloud, PlayCircle, Calculator, BarChart3, Network, Lightbulb, ArrowRight } from 'lucide-react'
import { useDataset } from '../context/DataContext'

const FEATURES = [
  {
    icon: Calculator,
    title: 'Statistical Analysis',
    text: 'Mean, median, mode, variance, standard deviation and quartiles computed for every numeric column.',
  },
  {
    icon: BarChart3,
    title: 'Data Visualization',
    text: 'Seven interactive chart types — bar, line, histogram, box plot, pie, scatter and heatmap.',
  },
  {
    icon: Network,
    title: 'Correlation Analysis',
    text: 'A full correlation matrix that surfaces the strongest positive and negative relationships.',
  },
  {
    icon: Lightbulb,
    title: 'Insight Generation',
    text: 'Automatic, plain-language observations about trends, outliers, gaps, and dominant categories.',
  },
]

export default function Home() {
  const navigate = useNavigate()
  const { loadDemo } = useDataset()

  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-3xl bg-brand-gradient px-6 sm:px-12 py-14 sm:py-20 text-white animate-rise">
        <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-28 -left-16 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
        <div className="relative max-w-2xl">
          <span className="inline-block text-[11px] font-bold tracking-wide uppercase bg-white/15 px-3 py-1 rounded-full">
            Data Science · College Project
          </span>
          <h1 className="font-display font-extrabold text-3xl sm:text-5xl mt-5 leading-tight">
            Exploratory Data Analysis
          </h1>
          <p className="text-lg sm:text-xl font-medium text-white/90 mt-3">
            Discover patterns. Understand data. Generate insights.
          </p>
          <p className="text-sm sm:text-base text-white/75 mt-5 leading-relaxed max-w-xl">
            Exploratory Data Analysis (EDA) is the practice of examining a dataset before modelling it —
            summarizing its main characteristics, spotting missing values and outliers, and visualizing
            relationships between variables. This dashboard automates that process: upload any CSV or
            Excel file and instantly get statistics, charts, correlations and written insights.
          </p>

          <div className="flex flex-wrap gap-3 mt-8">
            <button
              onClick={() => navigate('/upload')}
              className="inline-flex items-center gap-2 bg-white text-brand-purpleDeep font-semibold text-sm px-5 py-3 rounded-xl hover:bg-white/90 transition-colors"
            >
              <UploadCloud size={17} /> Upload Dataset
            </button>
            <button
              onClick={() => {
                loadDemo()
                navigate('/overview')
              }}
              className="inline-flex items-center gap-2 bg-white/10 border border-white/30 text-white font-semibold text-sm px-5 py-3 rounded-xl hover:bg-white/20 transition-colors"
            >
              <PlayCircle size={17} /> Explore Demo Dataset
            </button>
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-end justify-between mb-5">
          <div>
            <h2 className="font-display font-bold text-xl text-ink-900">What this dashboard does</h2>
            <p className="text-sm text-ink-300 mt-1">Four core capabilities, applied automatically to whatever you upload.</p>
          </div>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {FEATURES.map((f, i) => (
            <div key={f.title} className="card p-6 animate-rise" style={{ animationDelay: `${i * 60}ms` }}>
              <div className="h-11 w-11 rounded-xl bg-brand-gradient-soft grid place-items-center mb-4">
                <f.icon size={20} className="text-brand-purple" />
              </div>
              <h3 className="font-display font-bold text-ink-900 text-sm">{f.title}</h3>
              <p className="text-sm text-ink-300 mt-2 leading-relaxed">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
        <div>
          <h3 className="font-display font-bold text-lg text-ink-900">Ready to explore your own data?</h3>
          <p className="text-sm text-ink-300 mt-1">CSV and Excel files are supported — nothing leaves your browser.</p>
        </div>
        <button
          onClick={() => navigate('/upload')}
          className="inline-flex items-center gap-2 bg-brand-gradient text-white font-semibold text-sm px-5 py-3 rounded-xl shadow-pop hover:opacity-90 transition-opacity shrink-0"
        >
          Get Started <ArrowRight size={16} />
        </button>
      </section>
    </div>
  )
}
