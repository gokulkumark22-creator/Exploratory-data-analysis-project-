import React, { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { Rows3, Columns3, AlertTriangle, Copy, LayoutDashboard, ArrowRight } from 'lucide-react'
import {
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts'
import { useDataset } from '../context/DataContext'
import EmptyState from '../components/EmptyState'
import StatCard from '../components/StatCard'
import SectionHeader from '../components/SectionHeader'
import QualityGauge from '../components/QualityGauge'
import InsightCard from '../components/InsightCard'
import { summarizeColumn, countDuplicateRows, dataQualityScore } from '../utils/statistics'
import { buildCorrelationMatrix, topCorrelationPairs } from '../utils/correlation'
import { generateInsights } from '../utils/insights'
import { pieData, groupByAggregate } from '../utils/chartData'

const PALETTE = ['#3557E8', '#8B4FE8', '#12B886', '#F4A623', '#EF5162', '#0EA5E9']

export default function Dashboard() {
  const { dataset } = useDataset()

  const model = useMemo(() => {
    if (!dataset) return null
    const summaries = dataset.columns.map((c) => summarizeColumn(c, dataset.rows.map((r) => r[c]), dataset.columnTypes[c]))
    const missingTotal = summaries.reduce((a, s) => a + s.missing, 0)
    const duplicateRows = countDuplicateRows(dataset.rows)
    const quality = dataQualityScore({ rows: dataset.rows, columns: dataset.columns, missingTotal, duplicateRows })
    const insights = generateInsights(dataset).slice(0, 4)

    let correlationSummary = null
    if (dataset.numericColumns.length >= 2) {
      const matrix = buildCorrelationMatrix(dataset.rows, dataset.numericColumns)
      const { positive, negative } = topCorrelationPairs(matrix, dataset.numericColumns, 3)
      correlationSummary = { positive, negative }
    }

    const catCol = dataset.categoricalColumns[0]
    const numCol = dataset.numericColumns[0]
    const pie = catCol ? pieData(dataset.rows, catCol, 6) : []
    const bar = catCol && numCol ? groupByAggregate(dataset.rows, catCol, numCol, 'mean', 8) : []

    return { missingTotal, duplicateRows, quality, insights, correlationSummary, catCol, numCol, pie, bar }
  }, [dataset])

  if (!dataset || !model) {
    return <EmptyState message="Upload a dataset — or explore the demo — to populate the full analytics dashboard." />
  }

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Rows3} label="Records" value={dataset.rowCount.toLocaleString()} accent="blue" />
        <StatCard icon={Columns3} label="Features" value={dataset.columnCount} accent="purple" />
        <StatCard icon={AlertTriangle} label="Missing Values" value={model.missingTotal} accent={model.missingTotal ? 'warn' : 'good'} />
        <StatCard icon={Copy} label="Duplicate Rows" value={model.duplicateRows} accent={model.duplicateRows ? 'bad' : 'good'} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="card p-6 flex items-center justify-center">
          <QualityGauge score={model.quality} />
        </div>

        {model.bar.length > 0 && (
          <div className="card p-6 lg:col-span-2">
            <SectionHeader
              icon={LayoutDashboard}
              title={`Average ${model.numCol} by ${model.catCol}`}
              description="Top categories from your dataset."
            />
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={model.bar}>
                <CartesianGrid strokeDasharray="3 3" stroke="#EEF0FA" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#5B5D78' }} interval={0} angle={-15} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 11, fill: '#5B5D78' }} />
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #EEF0FA', fontSize: 12 }} />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {model.bar.map((_, i) => (
                    <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {model.pie.length > 0 && (
          <div className="card p-6">
            <SectionHeader icon={LayoutDashboard} title={`${model.catCol} distribution`} />
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={model.pie} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                  {model.pie.map((_, i) => (
                    <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #EEF0FA', fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        <div className="card p-6 lg:col-span-2">
          <SectionHeader icon={LayoutDashboard} title="Correlation summary" description="Strongest relationships at a glance." />
          {model.correlationSummary ? (
            <div className="grid sm:grid-cols-2 gap-3">
              {[...model.correlationSummary.positive.slice(0, 2), ...model.correlationSummary.negative.slice(0, 2)].map((p) => (
                <div key={`${p.a}-${p.b}`} className="flex items-center justify-between bg-surface-soft rounded-xl px-4 py-3">
                  <p className="text-sm font-medium text-ink-700 truncate pr-2">
                    {p.a} ↔ {p.b}
                  </p>
                  <span className={`font-display font-bold ${p.value >= 0 ? 'text-state-good' : 'text-brand-purple'}`}>{p.value}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-ink-300">Not enough numeric columns for a correlation summary.</p>
          )}
          <Link to="/correlation" className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-blue mt-4 hover:underline">
            View full correlation matrix <ArrowRight size={13} />
          </Link>
        </div>
      </div>

      <div className="card p-6 sm:p-8">
        <SectionHeader icon={LayoutDashboard} title="Key findings" description="A quick summary — see the full Insights page for more." />
        <div className="grid sm:grid-cols-2 gap-4">
          {model.insights.map((insight, i) => (
            <InsightCard key={i} insight={insight} index={i} />
          ))}
        </div>
        <Link to="/insights" className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-blue mt-5 hover:underline">
          View all insights <ArrowRight size={13} />
        </Link>
      </div>
    </div>
  )
}
