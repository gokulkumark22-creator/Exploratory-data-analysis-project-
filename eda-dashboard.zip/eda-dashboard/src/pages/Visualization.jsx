import React from 'react'
import { BarChart3 } from 'lucide-react'
import { useDataset } from '../context/DataContext'
import EmptyState from '../components/EmptyState'
import SectionHeader from '../components/SectionHeader'
import ChartPanel from '../components/ChartPanel'

export default function Visualization() {
  const { dataset } = useDataset()

  if (!dataset) {
    return <EmptyState message="Upload a dataset to generate interactive bar, line, histogram, box plot, pie, scatter and heatmap charts." />
  }

  return (
    <div className="space-y-6">
      <div className="card p-6 sm:p-8">
        <SectionHeader
          icon={BarChart3}
          title="Interactive chart builder"
          description="Pick a chart type, then choose which columns to plot."
        />
        <ChartPanel dataset={dataset} />
      </div>
    </div>
  )
}
