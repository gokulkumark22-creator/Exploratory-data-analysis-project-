import React, { useMemo } from 'react'
import { Lightbulb } from 'lucide-react'
import { useDataset } from '../context/DataContext'
import EmptyState from '../components/EmptyState'
import SectionHeader from '../components/SectionHeader'
import InsightCard from '../components/InsightCard'
import { generateInsights } from '../utils/insights'

export default function Insights() {
  const { dataset } = useDataset()
  const insights = useMemo(() => (dataset ? generateInsights(dataset) : []), [dataset])

  if (!dataset) {
    return <EmptyState message="Upload a dataset to automatically generate written insights about trends, outliers and data quality." />
  }

  return (
    <div className="space-y-6">
      <div className="card p-6 sm:p-8">
        <SectionHeader
          icon={Lightbulb}
          title="Automatically generated insights"
          description={`${insights.length} observation(s) derived from "${dataset.fileName}".`}
        />
        <div className="grid sm:grid-cols-2 gap-4">
          {insights.map((insight, i) => (
            <InsightCard key={i} insight={insight} index={i} />
          ))}
        </div>
      </div>
    </div>
  )
}
