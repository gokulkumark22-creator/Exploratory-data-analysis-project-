import React, { useMemo } from 'react'
import { Rows3, Columns3, AlertTriangle, Copy, Hash, Type, ClipboardList } from 'lucide-react'
import { useDataset } from '../context/DataContext'
import EmptyState from '../components/EmptyState'
import StatCard from '../components/StatCard'
import SectionHeader from '../components/SectionHeader'
import { summarizeColumn, countDuplicateRows } from '../utils/statistics'

export default function Overview() {
  const { dataset } = useDataset()

  const summaries = useMemo(() => {
    if (!dataset) return []
    return dataset.columns.map((col) => summarizeColumn(col, dataset.rows.map((r) => r[col]), dataset.columnTypes[col]))
  }, [dataset])

  const missingTotal = useMemo(() => summaries.reduce((a, s) => a + s.missing, 0), [summaries])
  const duplicateRows = useMemo(() => (dataset ? countDuplicateRows(dataset.rows) : 0), [dataset])

  if (!dataset) {
    return <EmptyState message="Upload a dataset — or explore the demo — to see its structure, completeness, and summary statistics." />
  }

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Rows3} label="Records" value={dataset.rowCount.toLocaleString()} accent="blue" />
        <StatCard icon={Columns3} label="Features" value={dataset.columnCount} accent="purple" />
        <StatCard
          icon={AlertTriangle}
          label="Missing Values"
          value={missingTotal.toLocaleString()}
          hint={`${((missingTotal / (dataset.rowCount * dataset.columnCount)) * 100 || 0).toFixed(1)}% of all cells`}
          accent={missingTotal > 0 ? 'warn' : 'good'}
        />
        <StatCard
          icon={Copy}
          label="Duplicate Records"
          value={duplicateRows}
          hint={`${((duplicateRows / dataset.rowCount) * 100 || 0).toFixed(1)}% of rows`}
          accent={duplicateRows > 0 ? 'bad' : 'good'}
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="card p-6 lg:col-span-1">
          <SectionHeader icon={Type} title="Column types" description="Numeric vs. categorical breakdown." />
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-2 font-medium text-ink-700">
                <Hash size={14} className="text-brand-blue" /> Numeric
              </span>
              <span className="font-bold text-ink-900">{dataset.numericColumns.length}</span>
            </div>
            <div className="h-2 rounded-full bg-surface-soft overflow-hidden">
              <div
                className="h-full bg-brand-blue rounded-full"
                style={{ width: `${(dataset.numericColumns.length / dataset.columnCount) * 100}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-sm pt-2">
              <span className="flex items-center gap-2 font-medium text-ink-700">
                <Type size={14} className="text-brand-purple" /> Categorical
              </span>
              <span className="font-bold text-ink-900">{dataset.categoricalColumns.length}</span>
            </div>
            <div className="h-2 rounded-full bg-surface-soft overflow-hidden">
              <div
                className="h-full bg-brand-purple rounded-full"
                style={{ width: `${(dataset.categoricalColumns.length / dataset.columnCount) * 100}%` }}
              />
            </div>
          </div>
        </div>

        <div className="card p-6 lg:col-span-2">
          <SectionHeader icon={ClipboardList} title="Unique values per column" description="How varied each column's values are." />
          <div className="grid sm:grid-cols-2 gap-x-6 gap-y-2 max-h-[220px] overflow-y-auto scrollbar-thin pr-2">
            {summaries.map((s) => (
              <div key={s.name} className="flex items-center justify-between text-sm py-1.5 border-b border-surface-muted/70">
                <span className="text-ink-700 truncate pr-2">{s.name}</span>
                <span className="font-semibold text-ink-900 shrink-0">{s.unique.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card p-6 sm:p-8">
        <SectionHeader
          icon={ClipboardList}
          title="Summary statistics"
          description="Mean, median, min, max and standard deviation for numeric columns; top value for categorical columns."
        />
        <div className="table-scroll rounded-xl border border-surface-muted">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-surface-soft">
                {['Column', 'Type', 'Missing', 'Unique', 'Mean', 'Median', 'Std Dev', 'Min', 'Max'].map((h) => (
                  <th key={h} className="text-left font-semibold text-ink-500 px-4 py-3 whitespace-nowrap border-b border-surface-muted">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {summaries.map((s) => (
                <tr key={s.name} className="odd:bg-white even:bg-surface-soft/40">
                  <td className="px-4 py-2.5 font-medium text-ink-900 whitespace-nowrap border-b border-surface-muted/70">{s.name}</td>
                  <td className="px-4 py-2.5 border-b border-surface-muted/70">
                    <span
                      className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded-md ${
                        s.type === 'numeric' ? 'bg-blue-50 text-brand-blue' : 'bg-violet-50 text-brand-purple'
                      }`}
                    >
                      {s.type}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.missing}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.unique}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.type === 'numeric' ? s.mean ?? '—' : '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.type === 'numeric' ? s.median ?? '—' : '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.type === 'numeric' ? s.std ?? '—' : '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.type === 'numeric' ? s.min ?? '—' : '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.type === 'numeric' ? s.max ?? '—' : String(s.mode ?? '—')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
