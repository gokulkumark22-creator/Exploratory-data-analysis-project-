import React, { useMemo, useState } from 'react'
import { Calculator, Sigma, TrendingUp, Divide, ArrowDownUp, ArrowUp10, ArrowDown10 } from 'lucide-react'
import { useDataset } from '../context/DataContext'
import EmptyState from '../components/EmptyState'
import SectionHeader from '../components/SectionHeader'
import StatCard from '../components/StatCard'
import { summarizeColumn } from '../utils/statistics'

export default function Statistics() {
  const { dataset } = useDataset()
  const numericColumns = dataset?.numericColumns || []
  const [selected, setSelected] = useState(numericColumns[0])

  const activeCol = selected && numericColumns.includes(selected) ? selected : numericColumns[0]

  const stat = useMemo(() => {
    if (!dataset || !activeCol) return null
    return summarizeColumn(activeCol, dataset.rows.map((r) => r[activeCol]), 'numeric')
  }, [dataset, activeCol])

  const allSummaries = useMemo(() => {
    if (!dataset) return []
    return numericColumns.map((c) => summarizeColumn(c, dataset.rows.map((r) => r[c]), 'numeric'))
  }, [dataset, numericColumns])

  if (!dataset) {
    return <EmptyState message="Upload a dataset to compute mean, median, mode, variance, standard deviation and quartiles." />
  }

  if (!numericColumns.length) {
    return <EmptyState message="This dataset has no numeric columns to run statistical analysis on." />
  }

  return (
    <div className="space-y-6">
      <div className="card p-6 sm:p-8">
        <SectionHeader
          icon={Calculator}
          title="Choose a numeric column"
          description="Statistics update instantly as you switch columns."
        />
        <div className="flex flex-wrap gap-2">
          {numericColumns.map((col) => (
            <button
              key={col}
              onClick={() => setSelected(col)}
              className={`text-xs font-semibold px-3.5 py-2 rounded-xl border transition-colors
              ${
                activeCol === col
                  ? 'bg-brand-gradient text-white border-transparent shadow-pop'
                  : 'bg-white text-ink-500 border-surface-muted hover:border-brand-blue/40'
              }`}
            >
              {col}
            </button>
          ))}
        </div>
      </div>

      {stat && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={Sigma} label="Mean" value={stat.mean ?? '—'} accent="blue" />
          <StatCard icon={ArrowDownUp} label="Median" value={stat.median ?? '—'} accent="purple" />
          <StatCard icon={TrendingUp} label="Mode" value={stat.mode ?? '—'} accent="good" />
          <StatCard icon={Divide} label="Std. Deviation" value={stat.std ?? '—'} accent="warn" />
          <StatCard icon={Divide} label="Variance" value={stat.variance ?? '—'} accent="blue" />
          <StatCard icon={ArrowDown10} label="Minimum" value={stat.min ?? '—'} accent="good" />
          <StatCard icon={ArrowUp10} label="Maximum" value={stat.max ?? '—'} accent="bad" />
          <StatCard icon={Sigma} label="Missing" value={`${stat.missing} (${stat.missingPct}%)`} accent="warn" />
        </div>
      )}

      {stat && (
        <div className="card p-6 sm:p-8">
          <SectionHeader icon={Sigma} title="Quartiles" description={`Distribution of "${activeCol}" split into four equal parts.`} />
          <div className="grid grid-cols-3 gap-4">
            {[
              ['Q1 · 25th percentile', stat.q1],
              ['Q2 · Median', stat.q2],
              ['Q3 · 75th percentile', stat.q3],
            ].map(([label, val]) => (
              <div key={label} className="rounded-xl bg-surface-soft p-4 text-center">
                <p className="text-2xl font-display font-bold text-ink-900">{val ?? '—'}</p>
                <p className="text-xs text-ink-300 mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="card p-6 sm:p-8">
        <SectionHeader icon={Calculator} title="Summary statistics table" description="All numeric columns, side by side." />
        <div className="table-scroll rounded-xl border border-surface-muted">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-surface-soft">
                {['Column', 'Mean', 'Median', 'Mode', 'Std Dev', 'Variance', 'Min', 'Max', 'Q1', 'Q3'].map((h) => (
                  <th key={h} className="text-left font-semibold text-ink-500 px-4 py-3 whitespace-nowrap border-b border-surface-muted">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {allSummaries.map((s) => (
                <tr key={s.name} className="odd:bg-white even:bg-surface-soft/40">
                  <td className="px-4 py-2.5 font-medium text-ink-900 whitespace-nowrap border-b border-surface-muted/70">{s.name}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.mean ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.median ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.mode ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.std ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.variance ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.min ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.max ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.q1 ?? '—'}</td>
                  <td className="px-4 py-2.5 text-ink-700 border-b border-surface-muted/70">{s.q3 ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
