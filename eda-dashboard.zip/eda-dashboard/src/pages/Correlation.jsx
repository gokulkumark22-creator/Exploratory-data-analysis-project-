import React, { useMemo } from 'react'
import { Network, TrendingUp, TrendingDown, Info } from 'lucide-react'
import { useDataset } from '../context/DataContext'
import EmptyState from '../components/EmptyState'
import SectionHeader from '../components/SectionHeader'
import CorrelationHeatmap from '../components/CorrelationHeatmap'
import { buildCorrelationMatrix, topCorrelationPairs, correlationStrengthLabel } from '../utils/correlation'

export default function Correlation() {
  const { dataset } = useDataset()

  const { matrix, positive, negative, columns } = useMemo(() => {
    if (!dataset || dataset.numericColumns.length < 2) return { matrix: [], positive: [], negative: [], columns: [] }
    const cols = dataset.numericColumns
    const m = buildCorrelationMatrix(dataset.rows, cols)
    const { positive: pos, negative: neg } = topCorrelationPairs(m, cols, 6)
    return { matrix: m, positive: pos, negative: neg, columns: cols }
  }, [dataset])

  if (!dataset) {
    return <EmptyState message="Upload a dataset with at least two numeric columns to compute correlations." />
  }

  if (dataset.numericColumns.length < 2) {
    return <EmptyState message="This dataset needs at least two numeric columns to run a correlation analysis." />
  }

  return (
    <div className="space-y-6">
      <div className="card p-6 sm:p-8">
        <SectionHeader
          icon={Network}
          title="Correlation matrix"
          description="Pearson correlation coefficient between every pair of numeric columns, from -1 to +1."
        />
        <CorrelationHeatmap columns={columns} matrix={matrix} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="card p-6 sm:p-8">
          <SectionHeader icon={TrendingUp} title="Strongest positive relationships" />
          <div className="space-y-3">
            {positive.length ? (
              positive.map((p) => (
                <div key={`${p.a}-${p.b}`} className="flex items-center justify-between bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-3">
                  <div>
                    <p className="text-sm font-semibold text-ink-900">
                      {p.a} <span className="text-ink-300 font-normal">↔</span> {p.b}
                    </p>
                    <p className="text-xs text-state-good font-medium mt-0.5">{correlationStrengthLabel(p.value)} positive</p>
                  </div>
                  <span className="font-display font-bold text-state-good">{p.value}</span>
                </div>
              ))
            ) : (
              <p className="text-sm text-ink-300">No positive relationships found.</p>
            )}
          </div>
        </div>

        <div className="card p-6 sm:p-8">
          <SectionHeader icon={TrendingDown} title="Strongest negative relationships" />
          <div className="space-y-3">
            {negative.length ? (
              negative.map((p) => (
                <div key={`${p.a}-${p.b}`} className="flex items-center justify-between bg-violet-50 border border-violet-100 rounded-xl px-4 py-3">
                  <div>
                    <p className="text-sm font-semibold text-ink-900">
                      {p.a} <span className="text-ink-300 font-normal">↔</span> {p.b}
                    </p>
                    <p className="text-xs text-brand-purple font-medium mt-0.5">{correlationStrengthLabel(p.value)} negative</p>
                  </div>
                  <span className="font-display font-bold text-brand-purple">{p.value}</span>
                </div>
              ))
            ) : (
              <p className="text-sm text-ink-300">No negative relationships found.</p>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-2xl px-5 py-4">
        <Info size={18} className="text-brand-blue shrink-0 mt-0.5" />
        <p className="text-sm text-ink-700">
          <span className="font-semibold">Correlation does not imply causation.</span> Two variables can move together
          because of a shared underlying cause, coincidence, or sampling bias — not because one directly influences the other.
          Treat these relationships as starting points for further investigation, not conclusions.
        </p>
      </div>
    </div>
  )
}
