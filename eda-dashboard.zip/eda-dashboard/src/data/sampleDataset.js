// A deterministic synthetic "E-Commerce Orders" dataset used by the
// "Explore Demo Dataset" button on the Home page, so the whole dashboard
// can be demoed without needing to upload a real file.

function mulberry32(seed) {
  let a = seed
  return function rand() {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const rand = mulberry32(42)

const CATEGORIES = ['Electronics', 'Apparel', 'Home & Kitchen', 'Beauty', 'Sports', 'Books']
const REGIONS = ['North', 'South', 'East', 'West', 'Central']
const CHANNELS = ['Online', 'In-Store', 'Marketplace']

function pick(arr) {
  return arr[Math.floor(rand() * arr.length)]
}

function round2(n) {
  return Math.round(n * 100) / 100
}

function generateRow(i) {
  const category = pick(CATEGORIES)
  const region = pick(REGIONS)
  const channel = pick(CHANNELS)

  const basePrice = { Electronics: 220, Apparel: 45, 'Home & Kitchen': 70, Beauty: 28, Sports: 55, Books: 18 }[category]
  const unitPrice = round2(basePrice * (0.7 + rand() * 0.6))
  const unitsSold = Math.max(1, Math.round(rand() * 12))
  const discount = round2([0, 0, 0, 5, 10, 15, 20][Math.floor(rand() * 7)])
  const revenue = round2(unitPrice * unitsSold * (1 - discount / 100))

  const customerAge = Math.round(18 + rand() * 50)
  const deliveryDays = Math.max(1, Math.round(1 + rand() * 9 + (channel === 'In-Store' ? -1 : 0)))

  // Satisfaction correlates loosely (and inversely) with delivery time, plus noise.
  let satisfaction = round2(5 - deliveryDays * 0.25 + rand() * 1.5)
  satisfaction = Math.min(5, Math.max(1, satisfaction))

  const returnFlag = rand() < 0.08 + (deliveryDays > 7 ? 0.08 : 0) ? 'Yes' : 'No'

  // Inject a small number of missing values and a few outliers, like a real dataset.
  const missingSlot = rand() < 0.04
  const outlierSlot = rand() < 0.02

  return {
    OrderID: `ORD-${1000 + i}`,
    Category: category,
    Region: region,
    Channel: channel,
    UnitPrice: unitPrice,
    UnitsSold: unitsSold,
    Discount_Pct: discount,
    Revenue: outlierSlot ? round2(revenue * 6) : revenue,
    CustomerAge: missingSlot ? '' : customerAge,
    DeliveryDays: deliveryDays,
    SatisfactionScore: satisfaction,
    Returned: returnFlag,
  }
}

const ROWS = Array.from({ length: 140 }, (_, i) => generateRow(i))

// A couple of exact duplicate rows so the "duplicate detection" feature has
// something real to surface in the demo.
ROWS.push({ ...ROWS[10] })
ROWS.push({ ...ROWS[47] })

export const DEMO_DATASET_ROWS = ROWS
export const DEMO_DATASET_META = {
  fileName: 'ecommerce_orders_demo.csv',
  fileSizeLabel: '18.4 KB',
}
