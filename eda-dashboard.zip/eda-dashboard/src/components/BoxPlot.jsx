import React from 'react'

const COLORS = ['#3557E8', '#8B4FE8', '#12B886', '#F4A623', '#EF5162', '#0EA5E9', '#D946EF', '#22C55E']

export default function BoxPlot({ data, height = 320 }) {
  if (!data.length) return null

  const globalMin = Math.min(...data.map((d) => Math.min(d.min, ...(d.outliers || []))))
  const globalMax = Math.max(...data.map((d) => Math.max(d.max, ...(d.outliers || []))))
  const pad = (globalMax - globalMin) * 0.08 || 1
  const domainMin = globalMin - pad
  const domainMax = globalMax + pad

  const width = 640
  const marginLeft = 56
  const marginRight = 24
  const marginTop = 20
  const marginBottom = 36
  const plotWidth = width - marginLeft - marginRight
  const plotHeight = height - marginTop - marginBottom
  const bandWidth = plotWidth / data.length
  const boxWidth = Math.min(64, bandWidth * 0.45)

  const yScale = (v) => marginTop + plotHeight - ((v - domainMin) / (domainMax - domainMin)) * plotHeight

  const ticks = Array.from({ length: 5 }, (_, i) => domainMin + ((domainMax - domainMin) / 4) * i)

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ minWidth: 480 }}>
        {ticks.map((t, i) => (
          <g key={i}>
            <line
              x1={marginLeft}
              x2={width - marginRight}
              y1={yScale(t)}
              y2={yScale(t)}
              stroke="#EEF0FA"
              strokeWidth={1}
            />
            <text x={marginLeft - 10} y={yScale(t) + 4} fontSize="10" textAnchor="end" fill="#9698B3">
              {Math.round(t * 100) / 100}
            </text>
          </g>
        ))}

        {data.map((d, i) => {
          const cx = marginLeft + bandWidth * i + bandWidth / 2
          const color = COLORS[i % COLORS.length]
          return (
            <g key={d.name}>
              <line x1={cx} x2={cx} y1={yScale(d.max)} y2={yScale(d.q3)} stroke={color} strokeWidth={1.5} />
              <line x1={cx} x2={cx} y1={yScale(d.min)} y2={yScale(d.q1)} stroke={color} strokeWidth={1.5} />
              <line x1={cx - 10} x2={cx + 10} y1={yScale(d.max)} y2={yScale(d.max)} stroke={color} strokeWidth={1.5} />
              <line x1={cx - 10} x2={cx + 10} y1={yScale(d.min)} y2={yScale(d.min)} stroke={color} strokeWidth={1.5} />

              <rect
                x={cx - boxWidth / 2}
                y={yScale(d.q3)}
                width={boxWidth}
                height={Math.max(1, yScale(d.q1) - yScale(d.q3))}
                fill={`${color}26`}
                stroke={color}
                strokeWidth={1.5}
                rx={4}
              />
              <line
                x1={cx - boxWidth / 2}
                x2={cx + boxWidth / 2}
                y1={yScale(d.median)}
                y2={yScale(d.median)}
                stroke={color}
                strokeWidth={2.5}
              />

              {(d.outliers || []).map((o, oi) => (
                <circle key={oi} cx={cx} cy={yScale(o)} r={3} fill="#EF5162" fillOpacity={0.7} />
              ))}

              <text x={cx} y={height - 10} fontSize="11" fontWeight={600} textAnchor="middle" fill="#5B5D78">
                {d.name.length > 12 ? `${d.name.slice(0, 11)}…` : d.name}
              </text>
            </g>
          )
        })}
      </svg>
    </div>
  )
}
