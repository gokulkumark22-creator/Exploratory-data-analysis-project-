import React from 'react'
import {
  AlertTriangle,
  Copy,
  TrendingUp,
  TrendingDown,
  Target,
  PieChart,
  Crosshair,
  ShieldCheck,
  Sparkle,
} from 'lucide-react'

const CONFIG = {
  missing: { icon: AlertTriangle, accent: 'text-state-warn bg-amber-50 border-amber-100' },
  duplicate: { icon: Copy, accent: 'text-state-bad bg-rose-50 border-rose-100' },
  range: { icon: Target, accent: 'text-brand-blue bg-blue-50 border-blue-100' },
  outlier: { icon: Crosshair, accent: 'text-state-bad bg-rose-50 border-rose-100' },
  'correlation-positive': { icon: TrendingUp, accent: 'text-state-good bg-emerald-50 border-emerald-100' },
  'correlation-negative': { icon: TrendingDown, accent: 'text-brand-purple bg-violet-50 border-violet-100' },
  category: { icon: PieChart, accent: 'text-brand-purple bg-violet-50 border-violet-100' },
  influence: { icon: Sparkle, accent: 'text-brand-blue bg-blue-50 border-blue-100' },
  quality: { icon: ShieldCheck, accent: 'text-state-good bg-emerald-50 border-emerald-100' },
}

export default function InsightCard({ insight, index = 0 }) {
  const cfg = CONFIG[insight.type] || CONFIG.range
  const Icon = cfg.icon
  return (
    <div
      className="card p-5 flex gap-4 animate-rise"
      style={{ animationDelay: `${Math.min(index, 8) * 45}ms` }}
    >
      <div className={`h-10 w-10 shrink-0 rounded-xl grid place-items-center border ${cfg.accent}`}>
        <Icon size={18} />
      </div>
      <div className="min-w-0">
        <p className="font-semibold text-ink-900 text-sm">{insight.title}</p>
        <p className="text-sm text-ink-500 mt-1 leading-relaxed">{insight.text}</p>
      </div>
    </div>
  )
}
