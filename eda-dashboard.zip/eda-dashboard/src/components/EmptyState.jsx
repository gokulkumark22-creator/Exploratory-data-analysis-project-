import React from 'react'
import { useNavigate } from 'react-router-dom'
import { DatabaseZap, UploadCloud, PlayCircle } from 'lucide-react'
import { useDataset } from '../context/DataContext'

export default function EmptyState({ message = 'Upload a dataset to unlock this section.' }) {
  const navigate = useNavigate()
  const { loadDemo } = useDataset()

  return (
    <div className="card flex flex-col items-center text-center gap-4 py-16 px-6 animate-rise">
      <div className="h-16 w-16 rounded-2xl bg-brand-gradient-soft grid place-items-center">
        <DatabaseZap size={28} className="text-brand-purple" />
      </div>
      <div>
        <h3 className="font-display font-bold text-lg text-ink-900">No dataset loaded yet</h3>
        <p className="text-sm text-ink-300 mt-1 max-w-sm">{message}</p>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-3 mt-2">
        <button
          onClick={() => navigate('/upload')}
          className="inline-flex items-center gap-2 bg-brand-gradient text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-pop hover:opacity-90 transition-opacity"
        >
          <UploadCloud size={16} /> Upload Dataset
        </button>
        <button
          onClick={() => {
            loadDemo()
            navigate('/overview')
          }}
          className="inline-flex items-center gap-2 bg-white border border-surface-muted text-ink-700 text-sm font-semibold px-5 py-2.5 rounded-xl hover:border-brand-blue/40 transition-colors"
        >
          <PlayCircle size={16} /> Explore Demo Dataset
        </button>
      </div>
    </div>
  )
}
