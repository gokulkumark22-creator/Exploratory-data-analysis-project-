import React, { useMemo, useState } from 'react'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts'
import { BarChart3, LineChart as LineIcon, ListTree, BoxSelect, PieChart as PieIcon, ChartScatter as ScatterIcon, Grid3x3 } from 'lucide-react'
import BoxPlot from './BoxPlot'
import Heatmap from './Heatmap'
import { histogramBins, groupByAggregate, boxPlotStats, crosstab, pieData } from '../utils/chartData'

const PALETTE = ['#3557E8', '#8B4FE8', '#12B886', '#F4A623', '#EF5162', '#0EA5E9', '#D946EF', '#22C55E']

const CHART_TYPES = [
  { id: 'bar', label: 'Bar', icon: BarChart3 },
  { id: 'line', label: 'Line', icon: LineIcon },
  { id: 'histogram', label: 'Histogram', icon: ListTree },
  { id: 'box', label: 'Box Plot', icon: BoxSelect },
  { id: 'pie', label: 'Pie', icon: PieIcon },
  { id: 'scatter', label: 'Scatter', icon: ScatterIcon },
  { id: 'heatmap', label: 'Heatmap', icon: Grid3x3 },
]

function Select({ label, value, onChange, options }) {
  return (
    <label className="text-xs font-semibold text-ink-500 flex flex-col gap-1.5">
      {label}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="text-sm font-medium text-ink-900 bg-surface-soft border border-surface-muted rounded-lg px-3 py-2 min-w-[160px] focus:border-brand-blue outline-none"
      >
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </label>
  )
}

export default function ChartPanel({ dataset }) {
  const { rows, numericColumns, categoricalColumns, columns } = dataset
  const [chartType, setChartType] = useState('bar')

  const [catA, setCatA] = useState(categoricalColumns[0] || columns[0])
  const [numA, setNumA] = useState(numericColumns[0] || columns[0])
  const [numB, setNumB] = useState(numericColumns[1] || numericColumns[0] || columns[0])
  const [catB, setCatB] = useState(categoricalColumns[1] || categoricalColumns[0] || columns[0])
  const [groupBy, setGroupBy] = useState('__none__')

  const chartData = useMemo(() => {
    try {
      if (chartType === 'bar') return groupByAggregate(rows, catA, numA, 'mean')
      if (chartType === 'histogram') return histogramBins(rows.map((r) => r[numA]), 10)
      if (chartType === 'line') return rows.slice(0, 200).map((r, i) => ({ name: i + 1, value: Number(r[numA]) || 0 }))
      if (chartType === 'box') return boxPlotStats(rows, numA, groupBy === '__none__' ? null : groupBy)
      if (chartType === 'pie') return pieData(rows, catA)
      if (chartType === 'scatter') return rows.map((r) => ({ x: Number(r[numA]), y: Number(r[numB]) })).filter((p) => !Number.isNaN(p.x) && !Number.isNaN(p.y))
      if (chartType === 'heatmap') return crosstab(rows, catA, catB)
      return []
    } catch {
      return []
    }
  }, [chartType, rows, catA, catB, numA, numB, groupBy])

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-6">
        {CHART_TYPES.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setChartType(id)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3.5 py-2 rounded-xl border transition-colors
            ${
              chartType === id
                ? 'bg-brand-gradient text-white border-transparent shadow-pop'
                : 'bg-white text-ink-500 border-surface-muted hover:border-brand-blue/40'
            }`}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      <div className="flex flex-wrap gap-4 mb-6">
        {chartType === 'bar' && (
          <>
            <Select label="Category (X-axis)" value={catA} onChange={setCatA} options={categoricalColumns.length ? categoricalColumns : columns} />
            <Select label="Numeric value (Y-axis, avg)" value={numA} onChange={setNumA} options={numericColumns.length ? numericColumns : columns} />
          </>
        )}
        {chartType === 'line' && <Select label="Numeric column" value={numA} onChange={setNumA} options={numericColumns.length ? numericColumns : columns} />}
        {chartType === 'histogram' && <Select label="Numeric column" value={numA} onChange={setNumA} options={numericColumns.length ? numericColumns : columns} />}
        {chartType === 'box' && (
          <>
            <Select label="Numeric column" value={numA} onChange={setNumA} options={numericColumns.length ? numericColumns : columns} />
            <Select label="Group by" value={groupBy} onChange={setGroupBy} options={['__none__', ...categoricalColumns]} />
          </>
        )}
        {chartType === 'pie' && <Select label="Category column" value={catA} onChange={setCatA} options={categoricalColumns.length ? categoricalColumns : columns} />}
        {chartType === 'scatter' && (
          <>
            <Select label="X-axis (numeric)" value={numA} onChange={setNumA} options={numericColumns.length ? numericColumns : columns} />
            <Select label="Y-axis (numeric)" value={numB} onChange={setNumB} options={numericColumns.length ? numericColumns : columns} />
          </>
        )}
        {chartType === 'heatmap' && (
          <>
            <Select label="Rows (category)" value={catA} onChange={setCatA} options={categoricalColumns.length ? categoricalColumns : columns} />
            <Select label="Columns (category)" value={catB} onChange={setCatB} options={categoricalColumns.length ? categoricalColumns : columns} />
          </>
        )}
      </div>

      <div className="rounded-xl bg-white border border-surface-muted p-4">
        {chartType === 'bar' && (
          <ResponsiveContainer width="100%" height={340}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF0FA" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#5B5D78' }} interval={0} angle={-20} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 11, fill: '#5B5D78' }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #EEF0FA', fontSize: 12 }} />
              <Bar dataKey="value" name={`avg ${numA}`} radius={[6, 6, 0, 0]}>
                {chartData.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}

        {chartType === 'line' && (
          <ResponsiveContainer width="100%" height={340}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF0FA" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#5B5D78' }} label={{ value: 'Row index', position: 'insideBottom', offset: -4, fontSize: 11, fill: '#9698B3' }} />
              <YAxis tick={{ fontSize: 11, fill: '#5B5D78' }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #EEF0FA', fontSize: 12 }} />
              <Line type="monotone" dataKey="value" name={numA} stroke="#3557E8" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        )}

        {chartType === 'histogram' && (
          <ResponsiveContainer width="100%" height={340}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF0FA" />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#5B5D78' }} interval={0} angle={-30} textAnchor="end" height={70} />
              <YAxis tick={{ fontSize: 11, fill: '#5B5D78' }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #EEF0FA', fontSize: 12 }} />
              <Bar dataKey="count" name="Frequency" fill="#8B4FE8" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}

        {chartType === 'box' && <BoxPlot data={chartData} />}

        {chartType === 'pie' && (
          <ResponsiveContainer width="100%" height={340}>
            <PieChart>
              <Pie data={chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={120} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {chartData.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #EEF0FA', fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        )}

        {chartType === 'scatter' && (
          <ResponsiveContainer width="100%" height={340}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF0FA" />
              <XAxis dataKey="x" name={numA} tick={{ fontSize: 11, fill: '#5B5D78' }} />
              <YAxis dataKey="y" name={numB} tick={{ fontSize: 11, fill: '#5B5D78' }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ borderRadius: 12, border: '1px solid #EEF0FA', fontSize: 12 }} />
              <Scatter data={chartData} fill="#3557E8" fillOpacity={0.65} />
            </ScatterChart>
          </ResponsiveContainer>
        )}

        {chartType === 'heatmap' && chartData.grid && (
          <Heatmap
            rowsLabels={chartData.rowsLabels}
            colsLabels={chartData.colsLabels}
            grid={chartData.grid}
            colorFn={(v) => {
              const intensity = v / chartData.max
              return `rgba(53, 87, 232, ${0.08 + intensity * 0.82})`
            }}
            textColorFn={(v) => (v / chartData.max > 0.5 ? '#fff' : '#181A2A')}
          />
        )}
      </div>
    </div>
  )
}
