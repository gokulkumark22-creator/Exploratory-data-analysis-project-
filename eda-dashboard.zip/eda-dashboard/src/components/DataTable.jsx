import React, { useState, useMemo } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

export default function DataTable({ columns, rows, pageSize = 8, badges = {} }) {
  const [page, setPage] = useState(0)
  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize))
  const current = Math.min(page, totalPages - 1)

  const pageRows = useMemo(
    () => rows.slice(current * pageSize, current * pageSize + pageSize),
    [rows, current, pageSize]
  )

  return (
    <div>
      <div className="table-scroll rounded-xl border border-surface-muted">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="bg-surface-soft">
              {columns.map((col) => (
                <th key={col} className="text-left font-semibold text-ink-500 px-4 py-3 whitespace-nowrap border-b border-surface-muted">
                  <div className="flex items-center gap-1.5">
                    {col}
                    {badges[col] && (
                      <span
                        className={`text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-md ${
                          badges[col] === 'numeric'
                            ? 'bg-blue-50 text-brand-blue'
                            : 'bg-violet-50 text-brand-purple'
                        }`}
                      >
                        {badges[col] === 'numeric' ? '#' : 'ABC'}
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((row, i) => (
              <tr key={i} className="odd:bg-white even:bg-surface-soft/40 hover:bg-brand-lilac/40 transition-colors">
                {columns.map((col) => (
                  <td key={col} className="px-4 py-2.5 text-ink-700 whitespace-nowrap border-b border-surface-muted/70">
                    {row[col] === '' || row[col] === null || row[col] === undefined ? (
                      <span className="text-ink-300 italic">empty</span>
                    ) : (
                      String(row[col])
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {rows.length > pageSize && (
        <div className="flex items-center justify-between mt-3">
          <p className="text-xs text-ink-300">
            Showing {current * pageSize + 1}–{Math.min(rows.length, (current + 1) * pageSize)} of {rows.length} rows
          </p>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={current === 0}
              className="h-8 w-8 grid place-items-center rounded-lg border border-surface-muted text-ink-500 disabled:opacity-30 hover:border-brand-blue/40"
            >
              <ChevronLeft size={15} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={current >= totalPages - 1}
              className="h-8 w-8 grid place-items-center rounded-lg border border-surface-muted text-ink-500 disabled:opacity-30 hover:border-brand-blue/40"
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
