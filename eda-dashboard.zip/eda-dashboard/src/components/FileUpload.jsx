import React, { useCallback, useRef, useState } from 'react'
import { UploadCloud, FileSpreadsheet, AlertCircle, Loader2 } from 'lucide-react'
import { useDataset } from '../context/DataContext'

export default function FileUpload({ onLoaded }) {
  const { loadFile, status, error } = useDataset()
  const [dragging, setDragging] = useState(false)
  const inputRef = useRef(null)

  const handleFiles = useCallback(
    async (fileList) => {
      const file = fileList?.[0]
      if (!file) return
      try {
        await loadFile(file)
        onLoaded?.()
      } catch {
        // error state is surfaced via context; nothing else to do here
      }
    },
    [loadFile, onLoaded]
  )

  const onDrop = (e) => {
    e.preventDefault()
    setDragging(false)
    handleFiles(e.dataTransfer.files)
  }

  return (
    <div>
      <div
        onDragOver={(e) => {
          e.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
        className={`cursor-pointer rounded-2xl border-2 border-dashed p-10 sm:p-14 text-center transition-colors
        ${dragging ? 'border-brand-blue bg-brand-lilac/40' : 'border-ink-300/30 bg-surface-soft hover:border-brand-blue/50'}`}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />

        {status === 'loading' ? (
          <div className="flex flex-col items-center gap-3">
            <Loader2 size={34} className="text-brand-blue animate-spin" />
            <p className="text-sm font-semibold text-ink-700">Reading and analyzing your file…</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3">
            <div className="h-16 w-16 rounded-2xl bg-brand-gradient grid place-items-center shadow-pop">
              <UploadCloud size={28} className="text-white" />
            </div>
            <p className="font-display font-bold text-ink-900">Drag &amp; drop your dataset here</p>
            <p className="text-sm text-ink-300">or click to browse — supports .csv, .xlsx and .xls files</p>
            <span className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-blue bg-blue-50 px-3 py-1.5 rounded-full">
              <FileSpreadsheet size={13} /> Max file size 25 MB
            </span>
          </div>
        )}
      </div>

      {status === 'error' && error && (
        <div className="mt-4 flex items-start gap-2.5 bg-rose-50 border border-rose-100 text-state-bad text-sm px-4 py-3 rounded-xl">
          <AlertCircle size={17} className="shrink-0 mt-0.5" />
          <p>{error}</p>
        </div>
      )}
    </div>
  )
}
