import React from 'react'
import Heatmap from './Heatmap'

// Diverging scale: strong negative -> red, 0 -> near white, strong positive -> blue/purple
function diverging(value) {
  if (value === null || value === undefined) return '#F6F7FC'
  const t = Math.max(-1, Math.min(1, value))
  if (t >= 0) {
    // white -> brand blue/purple
    const r = Math.round(255 - t * (255 - 91))
    const g = Math.round(255 - t * (255 - 79))
    const b = Math.round(255 - t * (255 - 232))
    return `rgb(${r},${g},${b})`
  }
  const abs = Math.abs(t)
  const r = Math.round(255 - abs * (255 - 239))
  const g = Math.round(255 - abs * (255 - 81))
  const b = Math.round(255 - abs * (255 - 98))
  return `rgb(${r},${g},${b})`
}

export default function CorrelationHeatmap({ columns, matrix }) {
  return (
    <div>
      <Heatmap
        rowsLabels={columns}
        colsLabels={columns}
        grid={matrix}
        colorFn={(v) => diverging(v)}
        labelFn={(v) => (v === null ? '—' : v.toFixed(2))}
        textColorFn={(v) => (v !== null && Math.abs(v) >= 0.6 ? '#fff' : '#181A2A')}
      />
      <div className="flex items-center gap-3 mt-5 text-xs text-ink-300">
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-sm" style={{ background: diverging(-1) }} /> -1.0
        </span>
        <div className="flex-1 h-2 rounded-full" style={{ background: 'linear-gradient(90deg, rgb(239,81,98), #fff, rgb(91,79,232))' }} />
        <span className="flex items-center gap-1.5">
          +1.0 <span className="h-3 w-3 rounded-sm" style={{ background: diverging(1) }} />
        </span>
      </div>
    </div>
  )
}
