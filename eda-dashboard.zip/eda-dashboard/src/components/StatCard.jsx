import React from 'react'

export default function StatCard({ icon: Icon, label, value, hint, accent = 'blue', className = '' }) {
  const accents = {
    blue: 'from-brand-blue to-brand-blueDeep',
    purple: 'from-brand-purple to-brand-purpleDeep',
    good: 'from-state-good to-emerald-600',
    warn: 'from-state-warn to-amber-600',
    bad: 'from-state-bad to-rose-600',
  }

  return (
    <div className={`card p-5 flex items-start gap-4 animate-rise ${className}`}>
      {Icon && (
        <div className={`h-11 w-11 shrink-0 rounded-xl bg-gradient-to-br ${accents[accent]} grid place-items-center shadow-pop`}>
          <Icon size={19} className="text-white" />
        </div>
      )}
      <div className="min-w-0">
        <p className="text-xs font-semibold text-ink-300 uppercase tracking-wide">{label}</p>
        <p className="font-display text-2xl font-bold text-ink-900 mt-0.5 truncate">{value}</p>
        {hint && <p className="text-xs text-ink-300 mt-1">{hint}</p>}
      </div>
    </div>
  )
}
