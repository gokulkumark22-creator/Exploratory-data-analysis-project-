import React from 'react'

export default function QualityGauge({ score = 0, size = 128 }) {
  const stroke = 12
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (score / 100) * circumference

  const color = score >= 80 ? '#12B886' : score >= 55 ? '#F4A623' : '#EF5162'
  const label = score >= 80 ? 'Excellent' : score >= 55 ? 'Fair' : 'Needs attention'

  return (
    <div className="flex items-center gap-5">
      <svg width={size} height={size} className="-rotate-90 shrink-0">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="#EEF0FA" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.8s ease' }}
        />
        <text
          x="50%"
          y="50%"
          transform={`rotate(90 ${size / 2} ${size / 2})`}
          textAnchor="middle"
          dominantBaseline="middle"
          fontSize="26"
          fontWeight="800"
          fill="#181A2A"
          fontFamily="Sora, sans-serif"
        >
          {score}
        </text>
      </svg>
      <div>
        <p className="text-xs font-semibold text-ink-300 uppercase tracking-wide">Data Quality Score</p>
        <p className="font-display text-lg font-bold mt-0.5" style={{ color }}>
          {label}
        </p>
        <p className="text-xs text-ink-300 mt-1 max-w-[180px]">Based on completeness and duplicate records.</p>
      </div>
    </div>
  )
}
