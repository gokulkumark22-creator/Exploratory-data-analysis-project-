import React from 'react'

export default function SectionHeader({ icon: Icon, title, description, action }) {
  return (
    <div className="flex items-start justify-between gap-4 mb-5">
      <div className="flex items-start gap-3">
        {Icon && (
          <div className="h-10 w-10 shrink-0 rounded-xl bg-brand-gradient-soft grid place-items-center">
            <Icon size={18} className="text-brand-purple" />
          </div>
        )}
        <div>
          <h3 className="font-display font-bold text-ink-900 text-base sm:text-lg">{title}</h3>
          {description && <p className="text-sm text-ink-300 mt-0.5">{description}</p>}
        </div>
      </div>
      {action}
    </div>
  )
}
