import React, { useState } from 'react'
import { Outlet, useLocation, Link } from 'react-router-dom'
import { Menu, Database, CheckCircle2 } from 'lucide-react'
import Sidebar from './Sidebar'
import { useDataset } from '../context/DataContext'

const TITLES = {
  '/': { title: 'Exploratory Data Analysis', subtitle: 'Discover patterns. Understand data. Generate insights.' },
  '/upload': { title: 'Dataset Upload', subtitle: 'Bring in a CSV or Excel file to begin the analysis.' },
  '/overview': { title: 'Data Overview', subtitle: 'Structure, completeness, and shape of your dataset.' },
  '/statistics': { title: 'Statistical Analysis', subtitle: 'Descriptive statistics for every numeric feature.' },
  '/visualization': { title: 'Data Visualization', subtitle: 'Explore your data across seven chart types.' },
  '/correlation': { title: 'Correlation Analysis', subtitle: 'How numeric features relate to one another.' },
  '/insights': { title: 'Key Insights', subtitle: 'Automatically generated observations about your data.' },
  '/report': { title: 'Report Generation', subtitle: 'A structured summary of the full analysis.' },
  '/dashboard': { title: 'Dashboard', subtitle: 'A single view of the metrics that matter most.' },
}

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const location = useLocation()
  const { dataset, isDemo } = useDataset()
  const page = TITLES[location.pathname] || TITLES['/']

  return (
    <div className="min-h-screen flex bg-surface-soft">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-20 shrink-0 border-b border-surface-muted bg-white/80 backdrop-blur sticky top-0 z-20 flex items-center gap-4 px-5 lg:px-8">
          <button
            className="lg:hidden text-ink-500 hover:text-ink-900"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open navigation"
          >
            <Menu size={22} />
          </button>

          <div className="min-w-0">
            <h1 className="font-display font-bold text-lg sm:text-xl text-ink-900 truncate">{page.title}</h1>
            <p className="text-xs sm:text-sm text-ink-300 truncate hidden sm:block">{page.subtitle}</p>
          </div>

          <div className="ml-auto flex items-center gap-3">
            {dataset ? (
              <Link
                to="/dashboard"
                className="flex items-center gap-2 rounded-full border border-surface-muted bg-surface-soft pl-2.5 pr-3.5 py-1.5 hover:border-brand-blue/40 transition-colors"
              >
                <span className="h-6 w-6 rounded-full bg-brand-gradient grid place-items-center">
                  <CheckCircle2 size={13} className="text-white" />
                </span>
                <span className="text-xs font-semibold text-ink-700 max-w-[140px] truncate">
                  {dataset.fileName}
                </span>
                {isDemo && (
                  <span className="text-[10px] font-bold uppercase tracking-wide text-brand-purpleDeep bg-brand-lilac px-1.5 py-0.5 rounded-md">
                    Demo
                  </span>
                )}
              </Link>
            ) : (
              <Link
                to="/upload"
                className="flex items-center gap-2 rounded-full border border-dashed border-ink-300/50 text-ink-300 pl-2.5 pr-3.5 py-1.5 hover:border-brand-blue hover:text-brand-blue transition-colors"
              >
                <Database size={14} />
                <span className="text-xs font-semibold">No dataset loaded</span>
              </Link>
            )}
          </div>
        </header>

        <main className="flex-1 px-5 lg:px-8 py-6 lg:py-8 max-w-[1400px] w-full mx-auto">
          <Outlet />
        </main>

        <footer className="px-5 lg:px-8 py-6 text-center text-xs text-ink-300">
          EDA Studio — a college Data Science project · Built with React &amp; Recharts
        </footer>
      </div>
    </div>
  )
}
