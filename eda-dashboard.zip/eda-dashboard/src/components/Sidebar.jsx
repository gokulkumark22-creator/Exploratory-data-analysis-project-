import React from 'react'
import { NavLink } from 'react-router-dom'
import {
  Home,
  UploadCloud,
  ClipboardList,
  Calculator,
  BarChart3,
  Network,
  Lightbulb,
  FileText,
  LayoutDashboard,
  Sparkles,
  X,
} from 'lucide-react'

const NAV_ITEMS = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/upload', label: 'Upload Dataset', icon: UploadCloud },
  { to: '/overview', label: 'Data Overview', icon: ClipboardList },
  { to: '/statistics', label: 'Statistical Analysis', icon: Calculator },
  { to: '/visualization', label: 'Data Visualization', icon: BarChart3 },
  { to: '/correlation', label: 'Correlation Analysis', icon: Network },
  { to: '/insights', label: 'Key Insights', icon: Lightbulb },
  { to: '/report', label: 'Report Generation', icon: FileText },
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
]

export default function Sidebar({ open, onClose }) {
  return (
    <>
      {open && (
        <button
          aria-label="Close navigation"
          onClick={onClose}
          className="fixed inset-0 z-30 bg-ink-900/40 backdrop-blur-sm lg:hidden"
        />
      )}
      <aside
        className={`fixed z-40 inset-y-0 left-0 w-72 shrink-0 bg-white border-r border-surface-muted flex flex-col
        transition-transform duration-300 ease-out lg:translate-x-0 lg:static lg:z-auto
        ${open ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="flex items-center justify-between px-6 h-20 border-b border-surface-muted">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-xl bg-brand-gradient grid place-items-center shadow-pop">
              <Sparkles className="text-white" size={18} />
            </div>
            <div className="leading-tight">
              <p className="font-display font-bold text-ink-900 text-[15px]">EDA Studio</p>
              <p className="text-[11px] text-ink-300 font-medium tracking-wide">Data Science Toolkit</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden text-ink-300 hover:text-ink-700">
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-5 px-3 space-y-1 scrollbar-thin">
          {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) =>
                `group flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors
                ${
                  isActive
                    ? 'bg-brand-gradient text-white shadow-pop'
                    : 'text-ink-500 hover:bg-surface-soft hover:text-ink-900'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <Icon size={18} className={isActive ? 'text-white' : 'text-ink-300 group-hover:text-brand-purple'} />
                  <span>{label}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 m-3 mb-5 rounded-2xl bg-brand-gradient-soft border border-brand-lilac">
          <p className="text-xs font-semibold text-brand-purpleDeep">College EDA Project</p>
          <p className="text-[11px] text-ink-500 mt-1 leading-relaxed">
            Built for Data Science coursework, viva demonstrations, and portfolio presentation.
          </p>
        </div>
      </aside>
    </>
  )
}
