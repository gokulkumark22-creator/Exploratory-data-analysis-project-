import React, { useState } from 'react'

// colorFn(value) => css color string. labelFn(value) => cell display text.
// textColorFn(value) => css text color string, so callers control contrast
// based on their own color scale instead of guessing from raw magnitude.
export default function Heatmap({ rowsLabels, colsLabels, grid, colorFn, labelFn, textColorFn, cellSize = 56 }) {
  const [hover, setHover] = useState(null)

  return (
    <div className="overflow-auto">
      <div
        className="inline-grid"
        style={{
          gridTemplateColumns: `140px repeat(${colsLabels.length}, minmax(${cellSize}px, 1fr))`,
        }}
      >
        <div />
        {colsLabels.map((c) => (
          <div key={c} className="text-[11px] font-semibold text-ink-500 text-center px-1 pb-2 truncate" title={c}>
            {c}
          </div>
        ))}

        {rowsLabels.map((r, ri) => (
          <React.Fragment key={r}>
            <div className="text-[11px] font-semibold text-ink-500 flex items-center pr-3 truncate" title={r}>
              {r}
            </div>
            {colsLabels.map((c, ci) => {
              const value = grid[ri][ci]
              const isHover = hover && hover.ri === ri && hover.ci === ci
              return (
                <div
                  key={c}
                  onMouseEnter={() => setHover({ ri, ci })}
                  onMouseLeave={() => setHover(null)}
                  className="aspect-square m-0.5 rounded-lg grid place-items-center text-[11px] font-bold transition-transform"
                  style={{
                    background: colorFn(value),
                    color: textColorFn ? textColorFn(value) : '#181A2A',
                    transform: isHover ? 'scale(1.08)' : 'scale(1)',
                    boxShadow: isHover ? '0 4px 14px rgba(24,26,42,0.18)' : 'none',
                  }}
                  title={`${r} × ${c}: ${labelFn ? labelFn(value) : value}`}
                >
                  {labelFn ? labelFn(value) : value}
                </div>
              )
            })}
          </React.Fragment>
        ))}
      </div>
    </div>
  )
}
