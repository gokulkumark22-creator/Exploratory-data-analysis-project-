/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          900: '#181A2A',
          700: '#2E2F45',
          500: '#5B5D78',
          300: '#9698B3',
        },
        surface: {
          DEFAULT: '#FFFFFF',
          soft: '#F6F7FC',
          muted: '#EEF0FA',
        },
        brand: {
          blue: '#3557E8',
          blueDeep: '#1E2E8E',
          purple: '#8B4FE8',
          purpleDeep: '#5B22B8',
          lilac: '#EDE9FE',
        },
        state: {
          good: '#12B886',
          warn: '#F4A623',
          bad: '#EF5162',
        },
      },
      fontFamily: {
        display: ['"Sora"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(24,26,42,0.04), 0 8px 24px -12px rgba(53,87,232,0.18)',
        pop: '0 12px 32px -8px rgba(91,34,184,0.28)',
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(135deg, #3557E8 0%, #6A3FE0 55%, #8B4FE8 100%)',
        'brand-gradient-soft': 'linear-gradient(135deg, rgba(53,87,232,0.10) 0%, rgba(139,79,232,0.10) 100%)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      keyframes: {
        rise: {
          '0%': { opacity: 0, transform: 'translateY(10px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
        pulseSoft: {
          '0%,100%': { opacity: 1 },
          '50%': { opacity: 0.55 },
        },
      },
      animation: {
        rise: 'rise 0.5s ease-out both',
        pulseSoft: 'pulseSoft 1.8s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
