# EDA Studio — Exploratory Data Analysis Dashboard

A modern, interactive **Exploratory Data Analysis (EDA)** web application built for a college-level Data Science project. Upload a CSV or Excel dataset and instantly get statistics, visualizations, correlation analysis, automatically generated insights, and a downloadable report — all computed client-side in the browser.

![Tech](https://img.shields.io/badge/React-18-3557E8) ![Tech](https://img.shields.io/badge/Vite-5-8B4FE8) ![Tech](https://img.shields.io/badge/TailwindCSS-3-12B886) ![License](https://img.shields.io/badge/License-MIT-gray)

## ✨ Features

| Section | What it does |
|---|---|
| **Home** | Project intro, feature highlights, and quick-start CTAs |
| **Dataset Upload** | Drag-and-drop CSV / Excel upload with file metadata + preview |
| **Data Overview** | Row/column counts, missing values, duplicates, per-column summary |
| **Statistical Analysis** | Mean, median, mode, std. deviation, variance, min/max, quartiles |
| **Data Visualization** | 7 interactive chart types: bar, line, histogram, box plot, pie, scatter, heatmap |
| **Correlation Analysis** | Full Pearson correlation matrix + strongest relationships |
| **Key Insights** | Automatically generated, plain-language observations |
| **Report Generation** | Structured Markdown report you can download |
| **Dashboard** | KPIs, charts, correlation summary, key findings, and a data quality score |

Everything runs **entirely in the browser** — no backend, no data leaves the user's machine.

## 🧱 Tech Stack

- **React 18** + **React Router** — UI and navigation
- **Vite** — build tooling
- **Tailwind CSS** — styling
- **Recharts** — bar/line/histogram/pie/scatter charts
- **Custom SVG components** — box plots and heatmaps (not natively supported by Recharts)
- **PapaParse** — CSV parsing
- **SheetJS (xlsx)** — Excel parsing
- **lucide-react** — icons

## 🚀 Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Open http://localhost:5173
```

### Build for production

```bash
npm run build
npm run preview   # preview the production build locally
```

The production build is emitted to `dist/`.

## 📁 Project Structure

```
src/
├── components/        # Reusable UI: Sidebar, Layout, charts, cards, tables
├── context/            # DataContext — holds the active dataset app-wide
├── data/               # Synthetic demo dataset generator
├── pages/              # One file per route/section
├── utils/              # Statistics, correlation, chart-data prep, insights, report
├── App.jsx             # Route definitions
└── main.jsx            # Entry point
```

## 📊 Using the Dashboard

1. Go to **Dataset Upload** and drop in a `.csv`, `.xlsx`, or `.xls` file — or click **Explore Demo Dataset** on the Home page to try it instantly with a built-in synthetic e-commerce dataset.
2. Browse **Data Overview** for the dataset's shape and quality.
3. Open **Statistical Analysis** to inspect any numeric column in detail.
4. Build charts on **Data Visualization** by picking a chart type and columns.
5. Check **Correlation Analysis** for relationships between numeric features.
6. Read the auto-generated **Key Insights**.
7. Download a full **Report** summarizing everything.
8. Get the big picture on the **Dashboard**.

## 🌐 Deploying to GitHub Pages / Vercel / Netlify

This is a static Vite app, so it deploys anywhere that serves static files:

**GitHub Pages**
```bash
npm run build
# push the contents of dist/ to a gh-pages branch,
# or use the `gh-pages` npm package / a GitHub Actions workflow
```

**Vercel / Netlify** — just connect the repository; both auto-detect Vite:
- Build command: `npm run build`
- Output directory: `dist`

## 📄 License

MIT — see [LICENSE](./LICENSE).

---

Built as a Data Science coursework project — suitable for a viva demonstration, portfolio piece, or placement presentation.
